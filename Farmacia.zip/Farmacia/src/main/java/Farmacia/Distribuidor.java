package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:21 p. m.
 * Clase que implementa su interfaz con sus metodos
 */
public class Distribuidor implements IDistribuidor {

	private int intId;
	private String strNombre;
	public Distribuidor()
	{
		intId = 0;
		strNombre = "";
	}
	public int GetId()
	{
		return intId;
	}
	public String GetNombre()
	{
		return strNombre;
	}
	public void SetId(int id)
	{
		intId = id;
	}
	public void SetNombre(String nombre)
	{
		strNombre = nombre;
	}
}