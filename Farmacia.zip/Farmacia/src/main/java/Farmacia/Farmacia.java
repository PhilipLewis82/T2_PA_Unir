package Farmacia;


/**
 * Modelado en Enterprise Architect
 * author Philip Lewis
 * Actua como Main, frmMain.Java usa esta clase
 */
public class Farmacia implements IFarmacia
{
		IOrden orden = new Orden();

	public Farmacia()
	{

	}
        /**
        *Metodo CrearOrden, recibe parametros
        */ 
	public int CrearOrden(String NombreMedicamento, String NombreSede, int Cantidad, String NombreDistribuidor, String TipoDeMedicamento)
	{
		 orden = new Orden();
		 orden.GetMedicamento().SetNombre(NombreMedicamento);
		 orden.GetSede().SetNombre(NombreSede);
		 orden.SetCantidad(Cantidad);
		 orden.GetDistribuidor().SetNombre(NombreDistribuidor);
		 orden.GetMedicamento().SetTipo(TipoDeMedicamento);
		 orden.Crear();
		 return orden.GetNumeroPedido();
	}
        /**
        *Simulacion del DTO
        * Obtenemos numero de pedido, mensaje de creacion y direccion de sede
        */ 
	public String GetOrden()
	{
		return ""+orden.GetNumeroPedido();
	}
	public String ObtenerMensaje()
	{
		return orden.ObtenerMensaje();
	}
        public String GetDireccionSede()
        {
                return orden.GetDireccionSede();
        }
}