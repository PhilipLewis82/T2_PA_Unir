package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:22 p. m.
 * Clase que implementa su interfaz con sus metodos
 */
public class Medicamento implements IMedicamento
{
	private int intId;
	private String strNombre;
	private ITipoMedicamento itmTipo;
	public Medicamento()
	{
		intId = 0;
		strNombre = "";
	}
	public int GetId()
	{
		return intId;
	}
	public String GetNombre()
	{
		return strNombre;
	}
	public ITipoMedicamento GetTipo()
	{
		return itmTipo;
	}
	public void SetId(int id)
	{
		intId = id;
	}
	public void SetNombre(String nombre)
	{
		strNombre = nombre;
	}
	public void SetTipo(String tipo)
	{
		itmTipo = new TipoMedicamento();
		itmTipo.SetNombre(tipo);
	}
}//end Medicamento