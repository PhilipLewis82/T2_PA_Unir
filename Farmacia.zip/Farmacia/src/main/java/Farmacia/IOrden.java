package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:21 p. m.
 */
public interface IOrden {


	public int Crear();

	public int GetCantidad();

	public IDistribuidor GetDistribuidor();

	public IMedicamento GetMedicamento();

	public ISede GetSede();

	public String ObtenerMensaje();

	/**
	 * 
	 * @param cantidad
	 */
	public void SetCantidad(int cantidad);

	/**
	 * 
	 * @param distribuidor
	 */
	public void SetDistribuidor(String distribuidor);

	/**
	 * 
	 * @param medicamento
	 */
	public void SetMedicamento(String medicamento);

	/**
	 * 
	 * @param sede
	 */
	public void SetSede(String sede);

	public int GetNumeroPedido();
        
        public String GetDireccionSede();


}