package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:21 p. m.
 */
public interface IFarmacia {


	public int CrearOrden(String NombreMedicamento, String NombreSede, int Cantidad, String NombreDistribuidor, String TipoDeMedicamento);

	public String GetOrden();

	public String ObtenerMensaje();
        
        public String GetDireccionSede();



}