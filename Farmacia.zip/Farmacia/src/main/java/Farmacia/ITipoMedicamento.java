package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:21 p. m.
 */
public interface ITipoMedicamento {

	public int GetId();

	public String GetNombre();

	public void SetId(int NumeroDeId);

	public void SetNombre(String nombre);

}