package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:22 p. m.
 * Clase que implementa su interfaz con sus metodos
 */
public class TipoMedicamento implements ITipoMedicamento {

	private String strNombre;
	private int intID;
	public TipoMedicamento()
	{
		strNombre = "";
		intID = 0;
	}
	public int GetId()
	{
		return intID;
	}
	public String GetNombre()
	{
		return strNombre;
	}
	public void SetId(int NumeroDeId)
	{
		intID = NumeroDeId;
	}
        /**
        * @author Philip Lewis
        * Se asigna IDs a cada tipo de medicamento, por organizacion. Para simular un error
        * Se crea el ID -1 cuando "no seleccionen un tipo de medicamento"
        * intID = -1 para simular error de Tipo de Medicamento
        */
	public void SetNombre(String nombre)
	{
		strNombre = nombre;
		if (nombre == "Analgesico")
		{
			intID = 1;
		}
		else if (nombre == "Analeptico")
		{
			intID = 2;
		}
		else if (nombre == "Antiacido")
		{
			intID = 3;
		}
		else if (nombre == "Antidepresivo")
		{
			intID = 4;
		}
		else if (nombre == "Antibiotico")
		{
			intID = 5;
		}
		else
		{
			intID = -1;
		}
	}
}