package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:22 p. m.
 * Clase que implementa su interfaz con sus metodos
 */
public class Sede implements ISede {

	private String strDireccion;
	private int intId;
	private String strNombre;
	private TIPOSEDE tiTipoSede;

	public Sede()
	{
		strNombre = "";
		strDireccion = "";
		intId = 0;
		tiTipoSede = TIPOSEDE.Principal;
	}

	public String GetDireccion()
	{
		return strDireccion;
	}

	public int GetId()
	{
		return intId;
	}

	public String GetNombre()
	{
		return strNombre;
	}

	public TIPOSEDE GetTipo()
	{
		return tiTipoSede;
	}

	public void SetDireccion(String direccion)
	{
		strDireccion = direccion;
	}

	public void SetId(int id)
	{
		intId = id;
	}
        /**
         * Seteo del nombre de la sede, donde de acuerdo al nombre hace set
         * del tipo
         */
	public void SetNombre(String nombre)
	{
		strNombre = nombre;
                if (nombre == "Principal")
                {
                    SetTipo(TIPOSEDE.Principal); 
                    return;
                }
                    SetTipo(TIPOSEDE.Sucursal);
        }
	/**
         * De acuerdo al nombre de la sede, se hace set de la direccion
         */
	public void SetTipo(TIPOSEDE tipo)
	{
		tiTipoSede = tipo;
		if (tipo == TIPOSEDE.Principal)
		{
			intId = 0;
			strDireccion = "Calle de la Rosa n. 28";
			strNombre = "Farmacia Principal";
			return;
		}
		intId = 1;
		strDireccion = "es Calle Alcazabilla n. 3";
		strNombre = "Farmacia Sucursal";

	}
}//end Sede