package Farmacia;


import java.util.Random;

/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:22 p. m.
 * Clase que implementa su interfaz con sus metodos
 * Declara sus variables internas
 */
public class Orden implements IOrden

{
	private int intCantidad;
	private IDistribuidor idDistribuidorOrden;
	private int intId;
	private IMedicamento imMedicamentoAOrdenar;
	private int intNumeroPedido;
	private ISede isSedeOrden;
/**
 *Se inicializan variables
*/
	public Orden()
	{
		intCantidad = 0;
		intId = 0;
		intNumeroPedido = 0;
		isSedeOrden = new Sede();
		imMedicamentoAOrdenar = new Medicamento();
		idDistribuidorOrden = new Distribuidor();
	}
/**
 *Metodo para crear la orden
 * Generamos un numero de pedido random como consecutivo del pedido
 * Si retorna -1 el id del tipo de medicamento significa que señalamos un tipo de medicamento para simular el error
 * Getters y Setters de la clase
 */

	public int Crear()
	{
		if (imMedicamentoAOrdenar.GetTipo().GetId()==-1 )
		{
			return -1;
		}
		intNumeroPedido = new Random().nextInt(100);
		return intNumeroPedido;

	}
	public int GetNumeroPedido()
	{
		return intNumeroPedido;
	}
	public int GetCantidad()
	{
		return intCantidad;
	}
	public IDistribuidor GetDistribuidor()
	{
		return idDistribuidorOrden;
	}
	public IMedicamento GetMedicamento()
	{
		return imMedicamentoAOrdenar;
	}
	public ISede GetSede()
	{
		return isSedeOrden;
	}

/**
* Metodo que retorna el mensaje de exito o fracaso en la creacion de la orden
*/ 
	public String ObtenerMensaje()
	{
		if (imMedicamentoAOrdenar.GetTipo().GetId()==-1)
		{
			return "Ocurrio un error en la creacion de la orden";
		}
		return "Orden Creada Exitosamente";
	}
	public void SetCantidad(int cantidad)
	{
		intCantidad = cantidad;
	}
	public void SetDistribuidor(String distribuidor)
	{
		//LVL up!!
		idDistribuidorOrden.SetNombre(distribuidor);
	}
	public void SetMedicamento(String medicamento)
	{
		//Lvl up!!
		imMedicamentoAOrdenar.SetNombre(medicamento);
	}
	public void SetSede(String sede)
	{
		isSedeOrden = new Sede();
		isSedeOrden.SetNombre(sede);
	}
        public String GetDireccionSede()
        {
            return isSedeOrden.GetDireccion();
        }
}