package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:21 p. m.
 */
public interface ISede {

	public String GetDireccion();

	public int GetId();

	public String GetNombre();

	public TIPOSEDE GetTipo();

	/**
	 * 
	 * @param direccion    direccion
	 */
	public void SetDireccion(String direccion);

	/**
	 * 
	 * @param id    id
	 */
	public void SetId(int id);

	/**
	 * 
	 * @param nombre    nombre
	 */
	public void SetNombre(String nombre);

	/**
	 * 
	 * @param tipo    tipo
	 */
	public void SetTipo(TIPOSEDE tipo);

}