package Farmacia;


/**
 * author Philip Lewis
 * Modelado en Enterprise Architect
 * created 11-sept.-2023 10:42:22 p. m.
 * Enumerador para el tipo de Sede.
 */
public enum TIPOSEDE
{
	Principal,
	Sucursal
}